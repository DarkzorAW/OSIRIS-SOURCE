#pragma once

namespace StreamProofESP
{
    void render() noexcept;
    void updateInput() noexcept;
}
